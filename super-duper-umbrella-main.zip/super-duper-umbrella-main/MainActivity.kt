package com.example.balatrocompanion

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val captureRequest = 41
    private lateinit var apiKeyInput: EditText
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
        }
        root.addView(TextView(this).apply {
            text = "Balatro Companion"
            textSize = 26f
        })
        root.addView(TextView(this).apply {
            text = "Assistente flutuante experimental: captura autorizada da tela e análise das jogadas por IA. Não controla as cartas automaticamente."
            textSize = 15f
        }, marginParams(top = 8, bottom = 12))

        apiKeyInput = EditText(this).apply {
            hint = "Chave de API OpenAI (sk-...)"
            singleLine = true
            inputType = 129
            setText(getSharedPreferences("settings", MODE_PRIVATE).getString("api_key", "") ?: "")
        }
        root.addView(apiKeyInput, marginParams(bottom = 8))
        root.addView(TextView(this).apply {
            text = "A chave é guardada localmente neste aparelho. Não distribua o APK com sua chave configurada. O uso da API pode ter cobrança separada do ChatGPT."
            textSize = 13f
        }, marginParams(bottom = 12))

        root.addView(Button(this).apply {
            text = "1. Permitir janela flutuante"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                } else Toast.makeText(this@MainActivity, "Permissão já concedida", Toast.LENGTH_SHORT).show()
            }
        }, marginParams(bottom = 8))

        root.addView(Button(this).apply {
            text = "2. Salvar chave de API"
            setOnClickListener {
                val key = apiKeyInput.text.toString().trim()
                if (!key.startsWith("sk-") || key.length < 20) {
                    Toast.makeText(this@MainActivity, "Insira uma chave de API válida.", Toast.LENGTH_LONG).show()
                } else {
                    getSharedPreferences("settings", MODE_PRIVATE).edit().putString("api_key", key).apply()
                    Toast.makeText(this@MainActivity, "Chave salva localmente.", Toast.LENGTH_SHORT).show()
                }
            }
        }, marginParams(bottom = 8))

        root.addView(Button(this).apply {
            text = "3. Iniciar captura e assistente"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    Toast.makeText(this@MainActivity, "Conceda primeiro a permissão de janela flutuante.", Toast.LENGTH_LONG).show()
                    return@setOnClickListener
                }
                val key = getSharedPreferences("settings", MODE_PRIVATE).getString("api_key", "") ?: ""
                if (key.isBlank()) {
                    Toast.makeText(this@MainActivity, "Salve sua chave de API primeiro.", Toast.LENGTH_LONG).show()
                    return@setOnClickListener
                }
                val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                startActivityForResult(mgr.createScreenCaptureIntent(), captureRequest)
            }
        }, marginParams(bottom = 8))

        root.addView(Button(this).apply {
            text = "Parar assistente"
            setOnClickListener { stopService(Intent(this@MainActivity, OverlayCaptureService::class.java)) }
        }, marginParams(bottom = 12))

        status = TextView(this).apply {
            text = "Passos: permita a janela, salve a chave e inicie a captura. O Android perguntará se você autoriza o compartilhamento da tela."
            textSize = 14f
        }
        root.addView(status)
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun marginParams(top: Int = 0, bottom: Int = 0): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = top; bottomMargin = bottom
        }

    @Deprecated("Legacy result API used here to keep the example compact")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == captureRequest && resultCode == RESULT_OK && data != null) {
            val startIntent = Intent(this, OverlayCaptureService::class.java).apply {
                putExtra("result_code", resultCode)
                putExtra("result_data", data)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(startIntent) else startService(startIntent)
            status.text = "Assistente iniciado. Abra Balatro; a janela flutuante pode ser movida."
        } else {
            Toast.makeText(this, "Captura de tela não autorizada.", Toast.LENGTH_SHORT).show()
        }
    }
}
