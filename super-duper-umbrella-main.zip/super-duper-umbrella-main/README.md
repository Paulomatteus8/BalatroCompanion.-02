# Balatro Companion — protótipo Android

Projeto experimental de Android nativo (Kotlin): janela flutuante, captura de tela autorizada por MediaProjection e análise visual usando a API OpenAI.

## Requisitos
- Android Studio recente com suporte ao Android Gradle Plugin 8.7.3
- JDK 17
- Android SDK Platform 35
- Aparelho Android 8.0 (API 26) ou superior; teste recomendado em Android 13+
- Chave de API OpenAI com acesso a um modelo com visão e faturamento/créditos da API habilitados

## Abrir e gerar o APK
1. Descompacte `BalatroCompanionAndroid.zip`.
2. No Android Studio, use **Open** e selecione a pasta `BalatroCompanionAndroid` (a que contém `settings.gradle.kts`).
3. Aguarde a sincronização do Gradle. Instale o SDK 35 se o Android Studio pedir.
4. Conecte o telefone por USB com depuração USB habilitada, ou configure um emulador.
5. Clique em **Run** para instalar no aparelho. Para gerar o APK, use **Build > Build APK(s)**.
6. Abra o app no celular; permita a janela flutuante, informe sua chave de API e salve.
7. Toque em **Iniciar captura e assistente** e aceite a permissão de compartilhamento de tela do Android.
8. Abra Balatro. A janela pode ser movida pelo cabeçalho. Digite uma pergunta ou deixe a análise automática ativa.

## O que este protótipo implementa
- Janela flutuante Android que pode ser movida e ocultada.
- Captura autorizada da tela a cada cerca de 2 segundos.
- Envio automático de uma captura para análise de IA aproximadamente a cada 15 segundos.
- Perguntas manuais sobre a captura mais recente e respostas na janela flutuante.
- Ação para parar a captura.

## Limitações e segurança
- **Este projeto-fonte não foi compilado nem testado num aparelho nesta sessão.** Pode precisar de ajustes conforme a versão do Android, fabricante e versão das ferramentas.
- O protótipo observa e aconselha; não clica nas cartas, não controla o jogo e não aprende por reforço automaticamente.
- A captura pode incluir partes da interface flutuante, notificações ou outros dados visíveis. Feche/oculte informações privadas antes de iniciar.
- Cada análise envia a imagem e a pergunta para a API OpenAI. Isso pode gerar custos separados da assinatura ChatGPT. O intervalo automático é de 15 segundos para moderar o uso, mas pode ser alterado no código.
- A chave é guardada em preferências privadas do app, mas isso não equivale a um cofre seguro. Não distribua o aplicativo com sua chave configurada; para distribuir a outras pessoas, use um backend próprio.
- Alguns aparelhos podem limitar a captura em segundo plano ou suspender o processo para economizar bateria. O Android exige autorização expressa de captura e mostra uma notificação contínua.
- Este projeto não inclui `gradlew`/wrapper. O Android Studio normalmente resolve e baixa o Gradle compatível durante a sincronização; se não, será preciso configurar Gradle compatível com o plugin.

## Privacidade
A imagem é capturada no telefone e enviada à API apenas para gerar análises. Não use o assistente enquanto aparecerem senhas, dados financeiros, conversas privadas ou qualquer conteúdo que não queira enviar a um serviço externo.
