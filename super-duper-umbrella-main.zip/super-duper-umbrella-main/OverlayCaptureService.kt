package com.example.balatrocompanion

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.Base64
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.WindowManager.LayoutParams
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.max
import kotlin.math.min

class OverlayCaptureService : Service() {
    private val mainHandler = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var overlay: LinearLayout? = null
    private var bubble: TextView? = null
    private var answerText: TextView? = null
    private var questionInput: EditText? = null
    private var latestImage: String? = null
    private var lastAnalysisAt = 0L
    @Volatile private var busy = false
    private var widthPx = 720
    private var heightPx = 1280
    private var densityDpi = 1
    private var overlayParams: LayoutParams? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForegroundNotification()
        val resultCode = intent?.getIntExtra("result_code", Activity.RESULT_CANCELED) ?: Activity.RESULT_CANCELED
        @Suppress("DEPRECATION")
        val resultData: Intent? = if (Build.VERSION.SDK_INT >= 33) {
            intent?.getParcelableExtra("result_data", Intent::class.java)
        } else {
            intent?.getParcelableExtra("result_data")
        }
        if (resultCode != Activity.RESULT_OK || resultData == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        try {
            val wm = getSystemService(WINDOW_SERVICE) as WindowManager
            val metrics = DisplayMetrics()
            @Suppress("DEPRECATION")
            wm.defaultDisplay.getRealMetrics(metrics)
            widthPx = metrics.widthPixels
            heightPx = metrics.heightPixels
            densityDpi = metrics.densityDpi

            val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = manager.getMediaProjection(resultCode, resultData)
            projection?.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { stopSelf() }
            }, mainHandler)
            reader = ImageReader.newInstance(widthPx, heightPx, PixelFormat.RGBA_8888, 3)
            virtualDisplay = projection?.createVirtualDisplay(
                "BalatroCompanionCapture", widthPx, heightPx, densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                reader?.surface, null, mainHandler
            )
            createOverlay()
            scheduleCapture()
        } catch (e: Exception) {
            showStatus("Não foi possível iniciar a captura: ${e.message ?: "erro desconhecido"}")
            stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun startForegroundNotification() {
        val channelId = "balatro_companion"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(channelId, "Balatro Companion", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        val notification = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, channelId)
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
        }.setContentTitle("Balatro Companion ativo")
            .setContentText("Captura de tela habilitada. Use o botão Parar para encerrar.")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .build()
        startForeground(7, notification)
    }

    private fun createOverlay() {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(10, 8, 10, 8)
            setBackgroundColor(0xEE20242A.toInt())
        }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val title = TextView(this).apply {
            text = "Balatro • IA   (arraste aqui)"
            textSize = 15f
            setTextColor(0xFFFFFFFF.toInt())
        }
        header.addView(title, LinearLayout.LayoutParams(0, 44, 1f))
        header.addView(Button(this).apply {
            text = "Minimizar"
            setOnClickListener { minimizeOverlay() }
        }, LinearLayout.LayoutParams(105, 44))
        panel.addView(header)
        answerText = TextView(this).apply {
            text = "Captura ativa. A IA analisará a tela aproximadamente a cada 15 segundos."
            textSize = 13f
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(4, 6, 4, 6)
        }
        panel.addView(ScrollView(this).apply { addView(answerText) }, LinearLayout.LayoutParams(-1, 155))
        questionInput = EditText(this).apply {
            hint = "Ex.: qual mão devo jogar?"
            textSize = 14f
            setSingleLine(false)
            minLines = 1
            maxLines = 3
        }
        panel.addView(questionInput, LinearLayout.LayoutParams(-1, -2))
        panel.addView(Button(this).apply {
            text = "Enviar pergunta"
            setOnClickListener {
                overlay?.visibility = View.VISIBLE
                val question = questionInput?.text?.toString()?.trim().orEmpty()
                askAI(question.ifBlank { "Analise a tela atual de Balatro e recomende a melhor jogada." })
            }
        })
        panel.addView(Button(this).apply {
            text = "Analisar agora"
            setOnClickListener {
                overlay?.visibility = View.VISIBLE
                askAI("Analise o estado atual de Balatro e recomende a melhor jogada.")
            }
        })
        panel.addView(Button(this).apply {
            text = "Parar captura"
            setOnClickListener { stopSelf() }
        })
        overlay = panel
        val screenWidthDp = (widthPx / resources.displayMetrics.density).toInt()
        val panelWidthDp = min(320, max(250, screenWidthDp - 32))
        val params = LayoutParams(
            (panelWidthDp * resources.displayMetrics.density).toInt(),
            LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) LayoutParams.TYPE_APPLICATION_OVERLAY else LayoutParams.TYPE_PHONE,
            LayoutParams.FLAG_NOT_TOUCH_MODAL or LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 8
            y = 100
        }
        overlayParams = params
        title.setOnTouchListener(object : View.OnTouchListener {
            private var initialX = 0
            private var initialY = 0
            private var startX = 0f
            private var startY = 0f
            override fun onTouch(v: View, event: MotionEvent): Boolean {
                val p = overlayParams ?: return false
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        initialX = p.x; initialY = p.y; startX = event.rawX; startY = event.rawY
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        p.x = initialX - (event.rawX - startX).toInt()
                        p.y = initialY + (event.rawY - startY).toInt()
                        try { wm.updateViewLayout(panel, p) } catch (_: Exception) {}
                        return true
                    }
                }
                return event.action == MotionEvent.ACTION_UP
            }
        })
        try { wm.addView(panel, params) } catch (_: Exception) { showStatus("Não consegui abrir a janela flutuante. Confira a permissão de sobreposição.") }
    }


    private fun minimizeOverlay() {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        try { overlay?.visibility = View.GONE } catch (_: Exception) { }
        if (bubble != null) return
        val chip = TextView(this).apply {
            text = "B♠"
            textSize = 19f
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(14, 10, 14, 10)
            setBackgroundColor(0xEE20242A.toInt())
            setOnClickListener {
                try { overlay?.visibility = View.VISIBLE } catch (_: Exception) { }
                try { bubble?.let { wm.removeView(it) } } catch (_: Exception) { }
                bubble = null
            }
        }
        val params = LayoutParams(
            (58 * resources.displayMetrics.density).toInt(),
            (54 * resources.displayMetrics.density).toInt(),
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) LayoutParams.TYPE_APPLICATION_OVERLAY else LayoutParams.TYPE_PHONE,
            LayoutParams.FLAG_NOT_FOCUSABLE or LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END; x = 8; y = 120 }
        bubble = chip
        try { wm.addView(chip, params) } catch (_: Exception) { bubble = null; overlay?.visibility = View.VISIBLE }
    }

    private fun scheduleCapture() {
        val task = object : Runnable {
            override fun run() {
                if (projection == null) return
                try {
                    val image = reader?.acquireLatestImage()
                    if (image != null) {
                        try {
                            val plane = image.planes[0]
                            val buffer = plane.buffer
                            val pixelStride = plane.pixelStride
                            val rowStride = plane.rowStride
                            val rowPadding = rowStride - pixelStride * widthPx
                            val bitmap = Bitmap.createBitmap(widthPx + rowPadding / pixelStride, heightPx, Bitmap.Config.ARGB_8888)
                            bitmap.copyPixelsFromBuffer(buffer)
                            val cropped = Bitmap.createBitmap(bitmap, 0, 0, widthPx, heightPx)
                            val targetWidth = min(widthPx, 900)
                            val targetHeight = max(1, (heightPx * targetWidth.toFloat() / widthPx).toInt())
                            val scaled = Bitmap.createScaledBitmap(cropped, targetWidth, targetHeight, true)
                            val bytes = ByteArrayOutputStream()
                            scaled.compress(Bitmap.CompressFormat.JPEG, 65, bytes)
                            latestImage = Base64.encodeToString(bytes.toByteArray(), Base64.NO_WRAP)
                            bitmap.recycle(); cropped.recycle(); scaled.recycle()
                        } finally { image.close() }
                    }
                    val now = System.currentTimeMillis()
                    if (latestImage != null && now - lastAnalysisAt >= 15000 && !busy) {
                        lastAnalysisAt = now
                        askAI("Observe esta captura de Balatro. Descreva brevemente as cartas e Jokers que conseguir ler e recomende uma próxima jogada. Se algo estiver ilegível, avise sem inventar.")
                    }
                } catch (_: Exception) { }
                if (projection != null) mainHandler.postDelayed(this, 2000)
            }
        }
        mainHandler.postDelayed(task, 1200)
    }

    private fun askAI(question: String) {
        if (busy) { showStatus("Já estou analisando uma captura; aguarde a resposta."); return }
        val image = latestImage
        if (image.isNullOrBlank()) { showStatus("Ainda não há captura disponível. Aguarde alguns segundos."); return }
        val key = getSharedPreferences("settings", Context.MODE_PRIVATE).getString("api_key", "") ?: ""
        if (key.isBlank()) { showStatus("Falta configurar a chave de API na tela inicial."); return }
        busy = true
        showStatus("Analisando a tela…")
        scope.launch {
            val result = try { callOpenAI(key, question, image) }
            catch (e: Exception) { "Falha na análise: ${e.message ?: "erro de rede"}" }
            withContext(Dispatchers.Main) {
                busy = false
                showStatus(result)
            }
        }
    }

    private fun callOpenAI(key: String, question: String, image: String): String {
        val connection = (URL("https://api.openai.com/v1/responses").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 20000
            readTimeout = 45000
            doOutput = true
            setRequestProperty("Authorization", "Bearer $key")
            setRequestProperty("Content-Type", "application/json")
        }
        val userContent = JSONArray()
            .put(JSONObject().put("type", "input_text").put("text", question))
            .put(JSONObject().put("type", "input_image").put("image_url", "data:image/jpeg;base64,$image").put("detail", "high"))
        val body = JSONObject()
            .put("model", "gpt-4.1-mini")
            .put("max_output_tokens", 500)
            .put("input", JSONArray().put(JSONObject()
                .put("role", "user")
                .put("content", userContent)))
        connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        val code = connection.responseCode
        val stream = if (code in 200..299) connection.inputStream else connection.errorStream
        val response = stream.bufferedReader().use { it.readText() }
        connection.disconnect()
        if (code !in 200..299) {
            return "Erro da API ($code): " + try {
                JSONObject(response).optJSONObject("error")?.optString("message", response.take(400)) ?: response.take(400)
            } catch (_: Exception) { response.take(400) }
        }
        val json = JSONObject(response)
        val output = json.optJSONArray("output") ?: return "A API não retornou conteúdo legível."
        val texts = mutableListOf<String>()
        for (i in 0 until output.length()) {
            val content = output.optJSONObject(i)?.optJSONArray("content") ?: continue
            for (j in 0 until content.length()) {
                val part = content.optJSONObject(j) ?: continue
                if (part.optString("type") == "output_text") texts += part.optString("text")
            }
        }
        return texts.joinToString("\n\n").ifBlank { "A IA não retornou texto. Tente novamente." }
    }

    private fun showStatus(message: String) {
        mainHandler.post { answerText?.text = message }
    }

    private fun removeOverlay() {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        try { overlay?.let { wm.removeView(it) } } catch (_: Exception) { }
        try { bubble?.let { wm.removeView(it) } } catch (_: Exception) { }
        overlay = null
        bubble = null
    }

    override fun onDestroy() {
        scope.cancel()
        mainHandler.removeCallbacksAndMessages(null)
        removeOverlay()
        virtualDisplay?.release()
        reader?.close()
        projection?.stop()
        projection = null
        super.onDestroy()
    }
}
